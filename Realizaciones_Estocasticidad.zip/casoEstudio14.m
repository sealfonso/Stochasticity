a=0.99;
n=0:1:100;
x=zeros(200,101);
for i=1:200
    for j=1:length(n);
        if(j==1)
            x(i,j)=0;
        else
            x(i,j)=a*x(i,j-1)+normrnd(0,1);
        end
    end
end 

figure
for q=1:200
    plot(n,x(q,:))
    hold on
end
title('X[n] vs n')
xlabel('n')
ylabel('X[n]')










% model=arima('AR',0.99,'Variance',1);
% rng('default')
% Y=simulate(model,101,'NumPaths',1000);
% figure
% plot(Y)