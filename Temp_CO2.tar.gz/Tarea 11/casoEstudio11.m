fileID=fopen('Sun_Rad.txt','r');
readSun=fscanf(fileID,'%f%f%f',[3 361]);
sunrad=readSun';

fileID=fopen('Temp_CO2.txt','r');
readtempco2=fscanf(fileID,'%f%f%f',[3 30]);
tempco2=readtempco2';

matrad=zeros(12,30);
radvec=sunrad(:,3);
for i=1:30
    matrad(:,i)=radvec((((i-1)*12)+1):(i*12));
end

prom=(mean(matrad))';
anos=(61:1:90)';
matprom=[anos prom];

figure(1)
plot(anos,prom)
figure(2)
plot(anos,tempco2(:,2))
figure(3)
plot(anos,tempco2(:,3))


































